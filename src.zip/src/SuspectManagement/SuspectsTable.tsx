


import React, { useEffect, useMemo, useState } from 'react';
import {
  MaterialReactTable,
  useMaterialReactTable,
} from 'material-react-table';
import axios from 'axios';
import {
  Box,
  Snackbar,
  Alert,
  Select,
  MenuItem,
  FormControl
} from '@mui/material';

import { ho } from "../hosts";
// === المكون الرئيسي لجدول المشتبه بهم ===
const SuspectsTable = () => {
  const [suspectsData, setSuspectsData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
  const [updatingId, setUpdatingId] = useState(null);

  // دالة جلب البيانات من الخادم
  const getSuspectsData = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await axios.get(`http://${ho}:8084/index.php`, {
        params: { tableName: 'suspects', operation: 'show' },
      });

      if (response.data) {
        setSuspectsData(response.data);
      } else {
        setError(response.data.message || 'خطأ غير متوقع في البيانات المستلمة');
      }
    } catch (err) {
      console.error('Error fetching suspects data:', err);
      setError('فشل في الاتصال بالخادم. يرجى المحاولة مرة أخرى.');
    } finally {
      setIsLoading(false);
    }
  };

  // دالة تحديث حالة المشتبه به
  const updateSuspectStatus = async (suspectId, newStatus) => {
    
    setUpdatingId(suspectId);
    
    try {
      const response = await axios.post(`http://${ho}:8084`,{ id: suspectId,
        status: newStatus },{
          params :{
        tableName: 'suspects',
        operation: 'updateStatus',
       }
      });

      if (response.data.success) {
        setSnackbar({
          open: true,
          message: 'تم تحديث الحالة بنجاح',
          severity: 'success'
        });
            getSuspectsData();
        // تحديث البيانات المحلية
        setSuspectsData(prevData =>
          prevData.map(item =>
            item.id === suspectId
              ? { ...item, status: newStatus }
              : item
          )
        );
      } else {
        
        setSnackbar({
          open: true,
          message: response.data.message || 'فشل في تحديث الحالة',
          severity: 'error'
        });
      }
    } catch (err) {
      console.error('Error updating suspect status:', err);
      setSnackbar({
        open: true,
        message: 'فشل في الاتصال بالخادم',
        severity: 'error'
      });
    } finally {
      setUpdatingId(null);
    }
  };

  // جلب البيانات عند تحميل المكون
  useEffect(() => {
    getSuspectsData();
  }, [updatingId]);

  // تعريف الأعمدة
  const columns = useMemo(
    () => [
      { accessorKey: 'full_name', header: 'الاسم الكامل', size: 200 },
      {
        accessorKey: 'status',
        header: 'الحالة',
        size: 150,
        Cell: ({ cell, row }) => (
          <FormControl size="small" fullWidth>
            <Select
              value={cell.getValue()}
              onChange={(e) => updateSuspectStatus(row.original.id, e.target.value)}
              disabled={updatingId === row.original.id}
              sx={{
                backgroundColor: cell.getValue() === 'Wanted' ? '#ffebee' : 
                               cell.getValue() === 'Arrested' ? '#e8f5e8' : '#fff3e0',
                color: cell.getValue() === 'Wanted' ? '#c62828' : 
                      cell.getValue() === 'Arrested' ? '#2e7d32' : '#f57c00',
                fontWeight: 'bold',
                '& .MuiSelect-select': {
                  padding: '8px 12px',
                  textAlign: 'center'
                },
                '& .MuiOutlinedInput-notchedOutline': {
                  border: 'none'
                }
              }}
            >
              <MenuItem value="Wanted">
                <Box sx={{ color: '#c62828', fontWeight: 'bold' }}>مطلوب</Box>
              </MenuItem>
              <MenuItem value="Arrested">
                <Box sx={{ color: '#2e7d32', fontWeight: 'bold' }}>مقبوض عليه</Box>
              </MenuItem>
              <MenuItem value="Cleared">
                <Box sx={{ color: '#f57c00', fontWeight: 'bold' }}>تم التبرئة</Box>
              </MenuItem>
            </Select>
          </FormControl>
        ),
      },
      { accessorKey: 'national_id', header: 'الرقم الوطني', size: 150 },
      { accessorKey: 'age', header: 'العمر', size: 80 },
      { accessorKey: 'gender', header: 'الجنس', size: 80 },
      { accessorKey: 'phone', header: 'رقم الهاتف', size: 150 },
      { accessorKey: 'address', header: 'العنوان', size: 250 },
      { accessorKey: 'district_name', header: 'المديرية', size: 150 },
      { accessorKey: 'neighborhood_name', header: 'الحي', size: 150 },
      {
        accessorKey: 'created_at',
        header: 'تاريخ الإضافة',
        size: 180,
        Cell: ({ cell }) =>
          new Date(cell.getValue()).toLocaleString('ar-EG'),
      },
    ],
    [updatingId],
  );

  // إنشاء الجدول
  const table = useMaterialReactTable({
    columns,
    data: suspectsData,
    enableRtl: true,
    state: {
      isLoading,
      showAlertBanner: error !== null,
    },
    muiToolbarAlertBannerProps: error
      ? {
          color: 'error',
          children: error,
        }
      : undefined,
    muiTableContainerProps: {
      sx: {
        maxHeight: '600px',
        maxWidth: '1110px',
        minWidth: '1110px',
        overflow: 'auto',
        
      },
    },
  });

  return (
    <>
    <Box p={3}>
      <MaterialReactTable table={table} />
      </Box>
      {/* رسائل التنبيه */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={3000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
      >
        <Alert severity={snackbar.severity}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </>
  );
};

export default SuspectsTable;