import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';

import HomePage from '../Pages/Home';
import ManageAlerts from '../ManageAlerts'
import UserManagement from '../UserManagement';
import ReceivingReports from '../ReceivingReports/ReceivingReports';
import SystemReportsManager from "../SystemReports/SystemReportsManager";
import ManageReports from '../ManageReports';
import SuspectsTable from '../SuspectManagement/SuspectsTable';
import ReportsDashboard from '../ReportManagement/ReportTypesTable';
import AreaManagement from "../AreaManagement/AreaManagement";

import DepartmentManager from "../DepartmentManager/DepartmentManager"
import ShowNotificationManagement from "../ShowNotifications/ShowNotificationManagement";
const AppRoutes = () => {
  return (
    <Routes>
      {/* عندما يدخل المستخدم على / يحوله إلى /home */}
      <Route path="/" element={<Navigate to="/home" />} />

      {/* صفحة الرئيسية */}
      <Route path="/home" element={<HomePage />} />

      {/* صفحة إدارة التنبيهات */}
      <Route path="/manage/manageAlerts" element={<ManageAlerts />} />
      <Route path="/manage/userManagement" element={<UserManagement />} />
      <Route path="/manage/systemReportsManager" element={<SystemReportsManager />} />
      <Route path="/manage/manageReport" element={<ManageReports />} />
      <Route path="/manage/manageLocations" element={<AreaManagement />} />
      <Route path="/manage/suspectManagement" element={<SuspectsTable />} />
      <Route path="/manage/manageReceivingReports" element={<ReceivingReports />} />
      <Route path="/manage/departmentsManagement" element={<DepartmentManager />} />
      <Route path="/manage/manageNotifications" element={<ShowNotificationManagement />} />
    </Routes>
  );
};

export default AppRoutes;