// src/api/personApi.js
import axios from 'axios';

const api = axios.create({
  baseURL: 'http://127.0.0.1:8084'
});

export const getPersons = async () => {
  const response = await api.get('/get_users');
  alert(response.data);
  return response.data;
};

export const createPerson = async (values) => {
  const response = await api.post('/add_user', values);
  return response.data;
};

export const updateItem = async (items, resourceName, params = null) => {
  try {
    const result = await api.post(`/${resourceName}`, items, {
      params: {
        tableName: params.tableName,
        operation: params.operation,
      }
    });

    // التحقق من وجود خطأ في الرد
    if (result.data.status === 'error') {
      throw new Error(result.data.message);
    }

    if (result.data.status === 'warning') {
       alert(result.data.message);
        return result.data; // إرجاع البيانات مع التحذير
    }

    // إذا كان النجاح
    alert(result.data.message);
    return result.data;

  } catch (error) {
    // معالجة أنواع الأخطاء المختلفة
    if (error.response) {
      // الخطأ من السيرفر (كود 4xx أو 5xx)
      const errorMessage = error.response.data?.message || error.response.statusText;
      alert(errorMessage);
      alert(`خطأ من السيرفر: ${errorMessage}`);
    } else if (error.request) {
      // الطلب تم ولكن لم يتم استقبال رد
      console.error('لا يوجد اتصال بالسيرفر:', error.request);
      alert('لا يمكن الاتصال بالسيرفر، يرجى التحقق من الاتصال بالإنترنت');
    } else if (error instanceof Error) {
      // خطأ في إعداد الطلب
    alert(error.message);
      alert(`خطأ: ${error.message}`);
    } else {
      // خطأ غير معروف
      alert(error);
    }
    
    // يمكنك أيضاً إعادة الخطأ للتعامل معه في المكان الذي استدعى الدالة
    throw error;
  }
};

export const deleteItem = async (id, resourceName) => {
  await api.delete(`/${resourceName}/${id}`);
  alert("تم حذف البيانات");
};

export const getAllItems = async (resourceName,param = null ) => {
  try {
    const response = await api.get(`/${resourceName}`, { params: param });
          
    return response.data || [];
  } catch (error) {
    // تسجيل فقط، ثم إعادة رمي الخطأ ليصل إلى React Query
    alert(error);
    throw error;
  }
};

// Create new item
export const createItem = async (items, resourceName,params) => {
      alert(JSON.stringify(params));
  try {
    const response = await api.post(`/${resourceName}`, items,{params:{
          tableName: params.tableName,
          operation: params.operation,
        }});
    return response.data;
  } catch (error) {
    alert(error);
  }
};