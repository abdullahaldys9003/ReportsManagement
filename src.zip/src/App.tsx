import React, { useState, useMemo } from 'react';
import IconButton from '@mui/material/IconButton';
import TextField from '@mui/material/TextField';
import Tooltip from '@mui/material/Tooltip';
import SearchIcon from '@mui/icons-material/Search';
import Stack from '@mui/material/Stack';
import { AppProvider } from '@toolpad/core/AppProvider';
import { DashboardLayout, ThemeSwitcher } from '@toolpad/core/DashboardLayout';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import { arEG } from '@mui/material/locale';

import AppRoutes from './routes/AppRoutes.tsx';
import NAVIGATION from './navigationConfig.tsx';
import Footer from './Footer';

function ToolbarActionsSearch() {
  return (
    <Stack direction="row" alignItems="center">
      <Tooltip title="بحث" enterDelay={1000}>
        <div>
          <IconButton
            type="button"
            aria-label="search"
            sx={{
              display: { xs: 'inline-flex', md: 'none' },
            }}
          >
            <SearchIcon />
          </IconButton>
        </div>
      </Tooltip>
      <TextField
        label="بحث"
        variant="outlined"
        size="small"
        slotProps={{
          input: {
            endAdornment: (
              <IconButton type="button" aria-label="search" size="small">
                <SearchIcon />
              </IconButton>
            ),
            sx: { 
              pr: 0.5,
              textAlign: 'right'
            },
          },
        }}
        sx={{ 
          display: { xs: 'none', md: 'inline-block' }, 
          mr: 1,
          width: '200px'
        }}
      />
      <ThemeSwitcher />
    </Stack>
  );
}

function App() {
  const [session, setSession] = useState({
    user: {
      name: 'Bharat Kashyap',
      email: 'bharatkashyap@outlook.com',
      image: 'https://avatars.githubusercontent.com/u/19550456',
    },
  });

  const authentication = useMemo(() => {
    return {
      signIn: () => {
        setSession({
          user: {
            name: 'Bharat Kashyap',
            email: 'bharatkashyap@outlook.com',
            image: 'https://avatars.githubusercontent.com/u/19550456',
          },
        });
      },
      signOut: () => {
        setSession(null);
      },
    };
  }, []);

  const theme = useMemo(
    () =>
      createTheme(
        {
          cssVariables: {
            colorSchemeSelector: 'data-toolpad-color-scheme',
          },
          colorSchemes: { light: true, dark: true },
          breakpoints: {
            values: {
              xs: 0,
              sm: 600,
              md: 900,
              lg: 1200,
              xl: 1536,
            },
          },
          direction: 'rtl',
          palette: {
            primary: { main: '#264653' },
            secondary: { main: '#2a9d8f' },
          },
          components: {
            MuiAppBar: {
              styleOverrides: {
                root: {
                  height: '64px',
                  minHeight: '64px',
                },
              },
            },
            MuiToolbar: {
              styleOverrides: {
                root: {
                  minHeight: '64px !important',
                  padding: '0 16px',
                },
              },
            },
            MuiTableCell: {
              styleOverrides: {
                root: {
                  textAlign: "center",
                  border: '0.001px solid white',
                },
              },
            },
            MuiTableHead: {
              styleOverrides: {
                root: {
                  '& th': {
                    textAlign: "center",
                  },
                },
              },
            },
            MuiTable: {
              styleOverrides: {
                root: {
                  borderCollapse: 'collapse',
                },
              },
            },
          },
        },
        arEG
      ),
    []
  );

  return (
    <ThemeProvider theme={theme}>
      <AppProvider 
        navigation={NAVIGATION} 
        branding={{
          logo: '',
          title: '',
        }}
        session={session}
        authentication={authentication} 
      >
        <DashboardLayout 
          slots={{ toolbarActions: ToolbarActionsSearch }}
          sx={{
            '& .MuiAppBar-root': { 
              height: 64,
              minHeight: 64
            },
            '& .MuiToolbar-root': { 
              minHeight: '64px !important'
            }
          }}
        >
          <AppRoutes />
        </DashboardLayout>
        <Footer />
      </AppProvider>
    </ThemeProvider>
  );
}

export default App;