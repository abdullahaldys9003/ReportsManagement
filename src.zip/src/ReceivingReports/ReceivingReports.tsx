import React, { useEffect, useMemo, useState } from 'react';
import WantedDetails from "../WantedDetails";
import {
  MaterialReactTable,
  useMaterialReactTable,
} from 'material-react-table';
import axios from 'axios';
import {
  Box,
  Snackbar,
  Alert,
  Select,
  MenuItem,
  FormControl,
  Chip,
  Button,
  CircularProgress
} from '@mui/material';

import { ho } from "../hosts.ts";
// === المكون الرئيسي لجدول البلاغات ===
const ReceivingReports = () => {
  const [reportsData, setReportsData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
  const [updatingId, setUpdatingId] = useState(null);

  // دالة جلب البيانات من الخادم
  const getReportsData = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await axios.get(`http://${ho}:8084/index.php`, {
        params: { tableName: 'suspects', operation: 'showAllReports' },
      });

      if (response.data) {
        setReportsData(response.data);
      } else {
        setError(response.data.message || 'خطأ غير متوقع في البيانات المستلمة');
      }
    } catch (err) {
      console.error('Error fetching reports data:', err);
      setError('فشل في الاتصال بالخادم. يرجى المحاولة مرة أخرى.');
    } finally {
      setIsLoading(false);
    }
  };

  // دالة تحديث حالة البلاغ
  const updateReportStatus = async (reportId, newStatus) => {
    setUpdatingId(reportId);
    
    try {
      const response = await axios.post(`http://${ho}:8084/index.php`,{ id: reportId,
        status: newStatus },{
          params :{
        tableName: 'suspects',
        operation: 'updateReportsStatus',
      } });

      if (response.data && response.data.status === 'success') {
        setSnackbar({
          open: true,
          message: 'تم تحديث حالة البلاغ بنجاح',
          severity: 'success'
        });
        
        // إعادة تحميل البيانات من الخادم
        getReportsData();
        
      } else {
        setSnackbar({
          open: true,
          message: response.data?.message || 'فشل في تحديث حالة البلاغ',
          severity: 'error'
        });
      }
    } catch (err) {
      console.error('Error updating report status:', err);
      setSnackbar({
        open: true,
        message: 'فشل في الاتصال بالخادم',
        severity: 'error'
      });
    } finally {
      setUpdatingId(null);
    }
  };

  // جلب البيانات عند تحميل المكون
  useEffect(() => {
    getReportsData();
  }, []);

  // تعريف الأعمدة
  const columns = useMemo(
    () => [
      {
        accessorKey: 'report_id',
        header: 'رقم البلاغ',
        size: 100,
      },
      {
        accessorKey: 'description',
        header: 'وصف البلاغ',
        size: 300,
        Cell: ({ cell }) => (
          <Box sx={{ maxWidth: 300, overflow: 'hidden', textOverflow: 'ellipsis' }}>
            {cell.getValue()}
          </Box>
        ),
      },
      {
        accessorKey: 'main_type',
        header: 'النوع الرئيسي',
        size: 150,
      },
      {
        accessorKey: 'sub_type',
        header: 'النوع الفرعي',
        size: 150,
      },
      {
        accessorKey: 'status_report',
        header: 'حالة البلاغ',
        size: 150,
        Cell: ({ cell, row }) => (
          <FormControl size="small" fullWidth>
            <Select
              value={cell.getValue()}
              onChange={(e) => updateReportStatus(row.original.report_id, e.target.value)}
              disabled={updatingId === row.original.report_id}
              sx={{
                backgroundColor: cell.getValue() === 'opened' ? '#e3f2fd' : 
                               cell.getValue() === 'closed' ? '#e8f5e8' : '#fff3e0',
                color: cell.getValue() === 'opened' ? '#1976d2' : 
                      cell.getValue() === 'closed' ? '#2e7d32' : '#f57c00',
                fontWeight: 'bold',
                '& .MuiSelect-select': {
                  padding: '8px 12px',
                  textAlign: 'center'
                },
                '& .MuiOutlinedInput-notchedOutline': {
                  border: 'none'
                }
              }}
            >
              <MenuItem value="opened">
                <Box sx={{ color: '#1976d2', fontWeight: 'bold' }}>مفتوح</Box>
              </MenuItem>
              <MenuItem value="prosse">
                <Box sx={{ color: '#f57c00', fontWeight: 'bold' }}>قيد المعالجة</Box>
              </MenuItem>
              <MenuItem value="closed">
                <Box sx={{ color: '#2e7d32', fontWeight: 'bold' }}>مغلق</Box>
              </MenuItem>
            </Select>
            {updatingId === row.original.report_id && (
              <CircularProgress size={20} sx={{ position: 'absolute', right: 8, top: '50%', transform: 'translateY(-50%)' }} />
            )}
          </FormControl>
        ),
      },
      {
        accessorKey: 'department_name',
        header: 'القسم',
        size: 150,
        Cell: ({ cell }) => (
          <Chip 
            label={cell.getValue()} 
            color="primary" 
            variant="outlined" 
            size="small" 
          />
        ),
      },
      {
        accessorKey: 'district_name',
        header: 'المديرية',
        size: 120,
      },
      {
        accessorKey: 'neighborhood_name',
        header: 'الحي',
        size: 120,
      },
      {
        accessorKey: 'created_at',
        header: 'تاريخ البلاغ',
        size: 150,
        Cell: ({ cell }) =>
          new Date(cell.getValue()).toLocaleString('ar-EG'),
      },
    ],
    [updatingId],
  );

  // إنشاء الجدول
  const table = useMaterialReactTable({
    columns,
    data: reportsData,
    enableRtl: true,
    state: {
      isLoading,
      showAlertBanner: error !== null,
    },
    muiToolbarAlertBannerProps: error
      ? {
          color: 'error',
          children: error,
        }
      : undefined,
    muiTableContainerProps: {
      sx: {
        maxWidth:'900px',
        maxHeight: '600px',
        overflow: 'auto',
      },
    },
renderDetailPanel: ({ row }) => (
      <Box
        sx={{
          display: 'grid',
          margin: 'auto',
          gridTemplateColumns: '1fr 1fr',
          width: '100%',
        }}
      >
      <WantedDetails reportId={row.original.report_id} />

      </Box>
    ),

  });

  return (
    <>
    <Box p={3} m={1} sx= {{
        maxWidth:'900px',
        maxHeight: '600px',
        overflow: 'auto',
      }} >
      <MaterialReactTable table={table} />
      </Box>
      
      {/* رسائل التنبيه */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={3000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
      >
        <Alert severity={snackbar.severity}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </>
  );
};

export default ReceivingReports;