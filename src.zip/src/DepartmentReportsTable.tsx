import { useMemo,useEffect,useState} from 'react';
import {
  MaterialReactTable,
  type MRT_ColumnDef,
  useMaterialReactTable,
} from 'material-react-table';

import axios from 'axios';

import {
  Chip,
  Box,
  Paper,
  Typography,
  createTheme,
  ThemeProvider,
  CssBaseline,
  alpha,
  Card,
  CardContent,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from '@mui/material';
// الأيقونات
import AssignmentIcon from '@mui/icons-material/Assignment';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import PendingActionsIcon from '@mui/icons-material/PendingActions';
import LocationCityIcon from '@mui/icons-material/LocationCity';
import MapIcon from '@mui/icons-material/Map';
import AccountBalanceIcon from '@mui/icons-material/AccountBalance';

// ثيم أنيق مع ألوان هادئة
const theme = createTheme({
  palette: {
    primary: {
      main: '#2E7D32', // أخضر داكن أنيق
      light: '#81C784',
      dark: '#1B5E20',
    },
    secondary: {
      main: '#0288D1', // أزرق أنيق
      light: '#B3E5FC',
      dark: '#01579B',
    },
    background: {
      default: '#f9f9f9',
      paper: '#ffffff',
    },
  },
  typography: {
    fontFamily: '"Tajawal", "Helvetica", "Arial", sans-serif',
    fontSize: 14,
  },
  components: {
    MuiPaper: {
      styleOverrides: {
        root: {
          border: '1px solid #e0e0e0',
          borderRadius: '12px',
          transition: 'all 0.3s ease',
          '&:hover': {
            boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
          },
        },
      },
    },
    MuiTableRow: {
      styleOverrides: {
        root: {
          '&:hover': {
            backgroundColor: alpha('#2E7D32', 0.05),
          },
        },
      },
    },
  },
});


const ho ='10.0.1.164';
const getDepartment_statistics = async () => {
      const response = await axios.get(`http://${ho}:8084`, {
        params: { tableName: "department_statistics", operation: "show" }
      });
      return response.data;
      
};


// بيانات وهمية بناء على الاستعلام المقدم


const DepartmentReportsTable = () => {
  const [data, setData] = useState([]);
  
 
 useEffect(() => {
  const fetchData = async () => {
    try {
      const result = await getDepartment_statistics();
      setData(result); // النتيجة الفعلية من السيرفر
    } catch (error) {
      console.error("حدث خطأ أثناء جلب البيانات:", error);
    }
  };

  fetchData();
}, []);
 
  const columns = useMemo<MRT_ColumnDef<typeof data[0]>[]>(
    () => [
      {
        accessorKey: 'department_name',
        header: 'اسم الإدارة',
        size: 120,
        Cell: ({ cell }) => (
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <AccountBalanceIcon color="primary" fontSize="small" />
            <Typography variant="body2" fontWeight="500">
              {cell.getValue<string>()}
            </Typography>
          </Box>
        ),
      },
      {
        accessorKey: 'district_name',
        header: 'اسم الحي',
        size: 100,
        Cell: ({ cell }) => (
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <LocationCityIcon color="secondary" fontSize="small" />
            <Typography variant="body2">
              {cell.getValue<string>()}
            </Typography>
          </Box>
        ),
      },
      {
        accessorKey: 'neighborhood_name',
        header: 'اسم المنطقة',
        size: 100,
        Cell: ({ cell }) => (
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <MapIcon color="action" fontSize="small" />
            <Typography variant="body2">
              {cell.getValue<string>()}
            </Typography>
          </Box>
        ),
      },
      {
        accessorKey: 'total_reports',
        header: 'إجمالي البلاغات',
        size: 100,
        Cell: ({ cell }) => (
          <Chip
            icon={<AssignmentIcon />}
            label={cell.getValue<number>()}
            size="small"
            color="primary"
            variant="outlined"
          />
        ),
      },
      {
        accessorKey: 'opened_reports',
        header: 'البلاغات المفتوحة',
        size: 120,
        Cell: ({ cell }) => (
          <Chip
            icon={<PendingActionsIcon />}
            label={cell.getValue<number>()}
            size="small"
            color="warning"
            variant="outlined"
          />
        ),
      },
      {
        accessorKey: 'closed_reports',
        header: 'البلاغات المغلقة',
        size: 120,
        Cell: ({ cell }) => (
          <Chip
            icon={<CheckCircleIcon />}
            label={cell.getValue<number>()}
            size="small"
            color="success"
            variant="outlined"
          />
        ),
      },
      {
        id: 'completion_rate',
        header: 'نسبة الإنجاز',
        size: 100,
        Cell: ({ row }) => {
          const completionRate = Math.round(
            (row.original.closed_reports / row.original.total_reports) * 100
          );
          
          return (
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
              <Typography
                variant="body2"
                color={completionRate >= 70 ? 'success.main' : completionRate >= 50 ? 'warning.main' : 'error.main'}
                fontWeight="500"
              >
                {completionRate}%
              </Typography>
            </Box>
          );
        },
      },
    ],
    []
  );

  // حساب الإحصائيات الإجمالية
  const totalStats = useMemo(() => {
    return data.reduce((acc, item) => ({
      total_reports: acc.total_reports + item.total_reports,
      opened_reports: acc.opened_reports + item.opened_reports,
      closed_reports: acc.closed_reports + item.closed_reports,
    }), { total_reports: 0, opened_reports: 0, closed_reports: 0 });
  }, []);

  const table = useMaterialReactTable({
    columns,
    data,
    enablePagination: true,
    paginationDisplayMode: 'pages',
    muiPaginationProps: {
      size: 'small',
      shape: 'rounded',
    },
    enableSorting: true,
    initialState: {
      density: 'compact',
      sorting: [{ id: 'total_reports', desc: true }]
    },
    muiTablePaperProps: {
      elevation: 0,
      sx: {
        border: '1px solid #e0e0e0',
        overflow: 'hidden',
      },
    },
    renderTopToolbarCustomActions: () => (
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, p: 1 }}>
        <FormControl size="small" sx={{ minWidth: 120 }}>
          <InputLabel>الفترة</InputLabel>
          <Select
            value="month"
            label="الفترة"
            onChange={() => {}}
          >
            <MenuItem value="week">أسبوع</MenuItem>
            <MenuItem value="month">شهر</MenuItem>
            <MenuItem value="quarter">ربع سنة</MenuItem>
            <MenuItem value="year">سنة</MenuItem>
          </Select>
        </FormControl>
      </Box>
    ),
  });

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Box sx={{ p: 2 }}>
        <Typography
          variant="h4"
          gutterBottom
          sx={{
            color: 'primary.main',
            fontWeight: '600',
            textAlign: 'center',
            mb: 3,
          }}
        >
          إحصائيات البلاغات حسب الإدارات والمناطق
        </Typography>
        
        {/* بطاقات الإحصائيات الإجمالية */}
        <Grid container spacing={2} sx={{ mb: 3 }}>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent sx={{ textAlign: 'center' }}>
                <AssignmentIcon color="primary" sx={{ fontSize: 40, mb: 1 }} />
                <Typography variant="h5" fontWeight="bold">
                  {totalStats.total_reports}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  إجمالي البلاغات
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent sx={{ textAlign: 'center' }}>
                <PendingActionsIcon color="warning" sx={{ fontSize: 40, mb: 1 }} />
                <Typography variant="h5" fontWeight="bold">
                  {totalStats.opened_reports}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  بلاغات مفتوحة
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent sx={{ textAlign: 'center' }}>
                <CheckCircleIcon color="success" sx={{ fontSize: 40, mb: 1 }} />
                <Typography variant="h5" fontWeight="bold">
                  {totalStats.closed_reports}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  بلاغات مغلقة
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent sx={{ textAlign: 'center' }}>
                <Typography 
                  variant="h5" 
                  fontWeight="bold"
                  color={
                    Math.round((totalStats.closed_reports / totalStats.total_reports) * 100) >= 70 
                    ? 'success.main' 
                    : Math.round((totalStats.closed_reports / totalStats.total_reports) * 100) >= 50 
                    ? 'warning.main' 
                    : 'error.main'
                  }
                >
                  {Math.round((totalStats.closed_reports / totalStats.total_reports) * 100)}%
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  نسبة الإنجاز
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>

        <Paper>
          <MaterialReactTable table={table} />
        </Paper>
      </Box>
    </ThemeProvider>
  );
};

export default DepartmentReportsTable;