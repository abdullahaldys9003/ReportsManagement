import * as React from 'react';
import Box from '@mui/material/Box';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
import StatisticsDepartmentReports from "./StatisticsDepartmentReports";
import HeatMapChart from "./HeatMapChart";
import ReportsGeoDashboard from "./ReportsGeoDashboard";
import ReportsTypeReporting from "./ReportsTypeReporting";
export default function SystemReportsManager() {
  const [value, setValue] = React.useState('1');

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <Box sx={{ width: '100%', typography: 'body1' }}>
      <TabContext value={value}>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <TabList onChange={handleChange} aria-label="lab API tabs example">
            <Tab label="تقارير بلاغات الاقسام" value="1" />
            <Tab label="تقارير حسب نوع البلاغ" value="2" />
            <Tab label="تقرير البلاغات حسب المناطق" value="3" />
          </TabList>
        </Box>
        <TabPanel value="1"><StatisticsDepartmentReports /> </TabPanel>
        <TabPanel value="2">
        <ReportsTypeReporting />
        </TabPanel>
        <TabPanel value="3"> 
        <ReportsGeoDashboard />
        </TabPanel>
      </TabContext>
    </Box>
  );
}
