import * as React from 'react';
import Box from '@mui/material/Box';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
import { QueryProvider } from "../providers/QueryProvider";
import { getAllItems } from '../api/crudApi.js';
// المكونات التي سيتم استيرادها لكل تبويب
//import AllSentTasks from './AllSentTasks';
import AllSentTasks from "./AllSentTasks";
//import PendingTasks from './PendingTasks';
//import InProgressTasks from './InProgressTasks';
//import CompletedTasks from './CompletedTasks';
//import RejectedTasks from './RejectedTasks';

export default function SentTasksManagement() {
  const [value, setValue] = React.useState('1');

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
   <QueryProvider>
    <Box sx={{ width: '100%', typography: 'body1' }}>
      <TabContext value={value}>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <TabList onChange={handleChange} aria-label="إدارة المهام الصادرة">
            <Tab label="الكل" value="1" />
            <Tab label="قيد الانتظار ⌛" value="2" />
            <Tab label="قيد التنفيذ 🛠️" value="3" />
            <Tab label="مكتملة ✅" value="4" />
            <Tab label="مرفوضة ❌" value="5" />
          </TabList>
        </Box>
        
        <TabPanel value="1">
          {/* جميع المهام المرسلة */}
          <AllSentTasks />
        </TabPanel>
        
        <TabPanel value="2">
          {/* المهام المنتظرة التنفيذ */}

        </TabPanel>
        
        <TabPanel value="3">
          {/* المهام قيد التنفيذ */}

        </TabPanel>
        
        <TabPanel value="4">
          {/* المهام المكتملة */}

        </TabPanel>
        
        <TabPanel value="5">
          {/* المهام المرفوضة */}

        </TabPanel>
      </TabContext>
    </Box>
    </QueryProvider>
  );
}